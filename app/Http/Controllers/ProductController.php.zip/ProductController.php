<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
class ProductController extends Controller
{
  public function Search() {
    $search_text = $_GET['query'];
$data['check_pro']=0;
       $data['searchproduct'] = DB::table('product')->where('title','LIKE','%'.$search_text.'%')->where('status',1)->get();

if(count($data['searchproduct'])<1){
  
      $data['searchproduct'] = DB::table('add_category')->where('name','LIKE','%'.$search_text.'%')->where('status',1)->get();

      if(count($data['searchproduct'])>0){
        $data['check_pro']=2;
      }

}
else{
    $data['check_pro']=1;
}


//  echo "<pre>";
//  print_r($data['searchproduct']);
//  die();
    // $product['searchproduct'] = DB::table('product')->where('title','LIKE','%'.$search_text.'%')->where('status',1)->get();
      $data['all_category'] = DB::table('add_category')->where('parent_category',0)->where('status',1)->get();
      $data['sub_category'] = DB::table('add_category')->where('parent_category','!=',0)->where('status',1)->get();
      $data['sub_category_link'] = DB::table('add_category')->where('status',1)->get();
      $data['all_product'] = DB::table('product')->where('status',1)->get();
      
      $data['meta'] = DB::table('dynamic')->where('page_url','search')->get();
      $data['meta_title'] = $data['meta']['0']->m_title;

      $data['dynamic'] = DB::table('dynamic')->get();
      $data['contact'] = DB::table('contact')->get();

      return view ('web/search/search',$data);
   
   
  }
//  search function 
   public function Product($url) {
 
    $data['value'] = DB::table('add_category')->where('category_url',$url)->where('status',1)->get();
    
    
  $data['sub_category_link'] = DB::table('add_category')->where('status',1)->get();
   $data['all_product'] = DB::table('product')->where('status',1)->get(); 
   $data['all_category'] = DB::table('add_category')->where('parent_category',0)->where('status',1)->get();
    $data['key_desc'] = DB::table('product')->where('url',$url)->where('status',1)->get();
    $data['dynamic'] = DB::table('dynamic')->get();
     $data['contact'] = DB::table('contact')->get();
  
    if(count($data['value'])>0){
   
      
     

      $data['sub'] = DB::table('add_category')->where('parent_category',$data['value'][0]->cat_id)->where('status',1)->get();

      $data['category'] = DB::table('add_category')->where('parent_category',$data['value'][0]->cat_id)->where('status',1)->get();
      
      $data['sub_product'] = DB::table('product')->where('cat_id',$data['value'][0]->cat_id)->where('status',1)->get();
    
     
     
      $data['meta_title']=  $data['value'][0]->meta_title;
        
      
      
  
   
      return view ('web/categories/categories', $data);
  }
    else {
     
      $data['value'] = DB::table('product')->where('url',$url)->where('status',1)->get();
    if(count($data['value'])>0){
       
      $data['value'] = DB::table('product')->where('url',$url)->where('status',1)->get();
    
     
      $data['product'] = DB::table('product')->where('url',$url)->get();
      $data['dimension'] = DB::table('dimension')->get();
      $data['meta_title'] = $data['product']['0']->meta_title;

  
      return view ('web/product/productdetails', $data);
    }
     else {
     
      $data['value'] = DB::table('dynamic')->where('page_url',$url)->where('status',1)->get();
    if(count($data['value'])>0){
      
      $data['value'] = DB::table('product')->where('url',$url)->where('status',1)->get();
      
      
     
      $data['meta'] = DB::table('dynamic')->where('page_url',$url)->get();
      $data['meta_title'] = $data['meta']['0']->m_title;

  
      return view ('web/dynamic/dynamic', $data);
    }
    else {
     
      $data['value'] = DB::table('blog')->where('blog_url',$url)->where('status',1)->get();
    if(count($data['value'])>0){
      
      $data['value'] = DB::table('product')->where('url',$url)->where('status',1)->get();
      
      
     
      $data['blog'] = DB::table('blog')->where('status',1)->orderBy('blog_id','DESC')->paginate(4);
      $data['meta'] = DB::table('blog')->where('blog_url',$url)->get();
      $data['meta_title'] = $data['meta']['0']->meta_title;

 
      return view ('web/blog/blogdetails', $data);
    }
    else{
      $data['other_single_product'] = DB::table('other_procuct')->where('other_produrl',$url)->get();
    $data['blog_single_value'] = DB::table('blog')->where('blog_url',$url)->where('status',1)->get();
   
   
   
    $data['all_blog'] = DB::table('blog')->where('status',1)->get(); 
   
    $data['top_blog'] = DB::table('blog')->orderBy('blog_id','desc')->limit(4)->get(); 
    $data['blog_main_banner'] = DB::table('blog_banner')->get(); 
    $data['meta_title']=  $data['other_single_product'][0]->meta_title;
      return view ('web/otherproduct/singleotherproduct',$data);
    }
      }
    }
  }
  }

 




}


?>
